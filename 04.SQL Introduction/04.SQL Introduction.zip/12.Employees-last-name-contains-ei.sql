SELECT e.FirstName + ' ' + e.LastName as [Employee Name]
FROM Employees e
WHERE e.LastName LIKE '%ei%'