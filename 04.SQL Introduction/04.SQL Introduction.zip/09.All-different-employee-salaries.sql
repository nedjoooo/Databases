SELECT DISTINCT e.Salary
FROM Employees e