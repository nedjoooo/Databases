SELECT e.FirstName + '.' + e.LastName + '@softuni.bg' as [Full Email Addresses]
FROM Employees e